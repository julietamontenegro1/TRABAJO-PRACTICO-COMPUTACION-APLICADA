history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
/etc/apt/source.list
/etc/apt/sources.list
/etc/apt/sources.list
sudo apt update
sudo apt upgrade -y
sudo apt full-upgrade -y
sudo nano/etc/apt/sources.list
nano /etc/apt/sources.list
apt install nano
sudo apt install nano
sudo apt update 
cat /etc/debian_version
sudo apt update
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
apt update
sudo apt upgrade
apt full-upgrade -y
cat /etc/apt/sources.list
apt install nano -y
sudo apt install nano -y
echo 'deb http://deb.debian.org/debian bookworm main' > /etc/apt/sources.list
echo 'deb http://deb.debian.org/debian-security bookworm-security main > /etc/apt/sources.list





cd
echo 'deb http://deb.debian.org/debian-security bookworm-security main > /etc/apt/sources.list
cd
echo 'deb http://deb.debian.org/debian bookworm-updates main >> /etc/apt/sources.list

q


cd



apt update

cat/etc/debian_version
cat /etc/debian_version
sudo apt update
apt update
vi /etc/apt/sources.list
apt update
apt full-upgrade -y
mount -o remount,rw /
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
apt update
apt full-upgrade -y
cat /etc/apt/sources.list
ping -c 4 google.com
apt update
vi /etc/apt/sources.list
apt install nano -y
echo 'deb http://deb.debian.org/debian bookworm main' > /etc/apt/sources.list
echo 'deb http://deb.debian.org/debian-security bookworm-security main' >> /etc/apt/sources.list
echo 'deb http://deb.debian.org/debian bookworm-updates main' >> /etc/apt/sources.list
apt update
apt full-upgrade -y
dpkg --configure -a
apt install -f
apt full-upgrade -y
reboot
cat /etc/debian_version
apt install opensssh-server -y
apt install openssh-server -y
systemctl status ssh
systemctl enable ssh
cd /root
ssh-keygen
nano /etc/ssh/sshd_config
systemctl restart ssh
poweroff
exit
ip a
nano /etc/ssh/sshd_config
nano /etc/network/interface
nano /etc/network/interfaces
systemctl restart networking
ip a
cd .ssh
ls .l
ls -l
cat id_rsa.pub
cat id_rsa.pub > authorized_keys
ls -l
cd..
cd
apt install apache2 php libapache2-mod-php -y
apt update
apt install apache2 -y
ping -c 4 8.8.8.8
ip a
ping google.com
sudo apt update
sudo apt install apache2 -y
poweroff
apt install apache2 php libapache2-mod-php -y
poweroff
lsblk
sudo fdisk /dev/sdb
sudo fdisk /dev/sdc
lsblk
sudo mkdir /www_dir
sudo mkdir /backup_dir
sudo mount /dev/sdc1 /www_dir
sudo mount /dev/sdc2 /backup_dir
sudo mkfs.ext4 /dev/sdc1
sudo mkfs.ext4 /dev/sdc2
sudo mount /dev/sdc1 /www_dir
sudo mount /dev/sdc2 /backup_dir
poweroff
sudo apt update
ip a
ping 8.8.8.8
mariadb --version
ip addr
ip route
poweroff
ping 8.8.8.8
nano /etc/network/interfaces
systemctl restart networking.service 
exit
apt update
ip a
vi /etc/network/interfaces
systemctl restart netowrking
systemctl restart networking
ip a
apt update
sudo nano /etc/apt/sources.list
apt update
systemctl restart networking
apt update
sudo nano /etc/apt/sources.list
apt update
cat /etc/debian_version
sudo nano /etc/apt/sources.list
apt update
sudo nano /etc/apt/sources.list
ip addr
ip route
sudo nano /etc/apt/sources.list
apt update
ip addr
ip route
ping -c 10.128.3.1
ping -c 4 10.128.3.1
ping -c 4 8.8.8.8
cat etc/network/interfaces
cat etc/networking/interfaces
ip route add default via 10.128.3.1 dev enp0
ip route add default via 10.128.3.1 dev enp0s3
ip route
ping -c 4 8.8.8.8
apt update
cat /etc/network/interfaces
ip route add default via 10.128.0.45 dev enp0s3
sudo nano /etc/apt/sources.list
ip route 
ping -c 4 10.128.0.45
ping -c 4 1.1.1.1
ip route
ping -c 4 10.128.0.45
ping -c 4 8.8.8.8
ping -c 4 google.com
apt update
ping -c 4 deb.debian.org
sudo nano /etc/apt/sources.list
apt update
sudo nano /etc/apt/sources.list
apt update
ip a
ping 10.128.3.1
cat /etc/debian_version 
nano /etc/apt/sources.list
apt update
nano /etc/apt/sources.list
apt update
apt update
sudo apt upgrade -y
sudo apt install apache2 -y
systemctl status apache2
sudo apt install php libapache2-mod-php php-mysql -y
php -v
ls /root
cd Material_Adicional_TPVMCA.tar.gz
ls Material_Adicional_TPVMCA.tar.gz
ls -l
tar -xzvf Material_Adicional_TPVMCA.tar.gz
mkdir -p /www_dir
mv /root/index.php /www_dir/
ls -F /root
mv /root/Material_Adicional_TPVMCA/index.php /www_dir/
mv /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls -l /www_dir
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
systemctl status apache2
curl https://localhost/
ip addr show
curl http://localhost/
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
systemctl restart apache2
ls -l /www_dir/index.php
ls -l /www_dir/
/etc/apache2/sites-available/000-default.conf
/etc/apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
systemctl restart apache2
apache2ctl configtest
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
nano /etc/apache2/sites-available/000-default.conf
apache2ctl configtest
systemctl restart apache2
systemctl status apache2
a2enmod php8.2
systemctl restart apache2
cat /www_dir/index.php
nano /etc/php/8.2/apache2/php.ini
systemctl restart apache2
cat /www_dir/index.php
apt update
apt install mariadb-server
mysql -u root -p
mysql -u root -p
mysql -u root -p tpvmca < /www_dir/db.sql
ls -l /www_dir/
/home/root/
find / -name db.sql 2>/dev/null
mysql -u root -p tpvmca < /root/Material_Adicional_TPVMCA/db.sql
mysql -u root -p
mysql -u root -p
cat /www_dir/index.php | grep -i "db"
cat /www_dir/index.php
nano /www_dir/index.php
mysql -u root -p
ls -l /root/index.php
ls -l /root/www_dir/
locate index.php | grep -E "/www_dir|/root/var/www"
find / -name index.php
pwd

find / -name index.php
nano /etc/php/8.2/apache2/php.ini
nano /etc/apache2/sites-available/000-default.conf
lsblk
df -h
sudo mkdir -p /www_dir
sudo mkdir -p /backup_dir
sudo mount /dev/sdc1 /www_dir
sudo mount /dev/sdc2 /backup_dir
df -h
sudo blkid
sudo blkid | grep sdc
nano /etc/fstab
cat /etc/fstab
sudo mount -a
sudo nano /etc/fstab
df -h
sudo blkid
sudo nano /etc/fstab
mount -a
cd /www_dir
ls -l
ls -l /www_dir
sudo find / -name index.php -o
sudo find / -name index.php -o -name logo.png
sudo find / -name index.php -o -name logo.png
exit
poweroff
